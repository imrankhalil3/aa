﻿namespace SehatClone.Models
{

    public class CenterType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}