﻿namespace SehatClone.ViewModel
{
    public class SearchVm
    {
        public string UserType { get; set; }
        public string SearchTxt { get; set; }
        public string Location { get; set; }
    }
}